﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Operations
{
    class OUser
    {
        public void Insert() { }
        public void Delete() { }
        public void Update() { }
        public void Select()
        {

        }
    }
}
