﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer.Operations;
using collegium.Students;
using collegium.Users;
using DataAccessLayer.Entities;
using DataAccessLayer.Repository;

namespace collegium
{
    public partial class frmMain : Form
    {
        public List<Student> Students { get; set; }
        public frmMain()
        {
            InitializeComponent();

            var student = new StudentRepository();
            Students = student.GetAll().ToList();
            
            var source = new BindingSource();
            source.DataSource = Students;
            dataGridView1.DataSource = source;
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            tsTime.Text  = DateTime.Now.ToString();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GeneralTools.ConfirmationBox("confirm?")) 
            {
                Application.Exit();
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            GeneralTools.SetUserLogged("bruno");
            setTsUserName();
            setTsFrmName();
        }
        private void setTsUserName()
        {
            tsUserName.Text = GeneralTools.GetUserLogged();
        }
        private void setTsFrmName(string frmName = "frmMain")
        {
            tsFrmName.Text = frmName;
        }

        private void viewDatabaseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            setTsFrmName("frmHistoryLog");
            frmHistoryLog obj = new frmHistoryLog();
            obj.ShowDialog();
            setTsFrmName();
        }

        private void newStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var newStudentForm = new FormNewStudent();

            newStudentForm.Show();
        }

        private void editStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var updateStudentForm = new FormUpdateStudent();

            updateStudentForm.Show();
        }

        private void deleteStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var deleteStudentForm = new FormDeleteStudent();

            deleteStudentForm.Show();
        }

        private void newUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var userNewForm = new FormNewUser();

            userNewForm.Show();
        }

        private void deleteUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var deleteForm = new FormDeleteUser();

            deleteForm.Show();
        }
    }
}
